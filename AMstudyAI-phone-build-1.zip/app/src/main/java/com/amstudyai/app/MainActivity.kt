package com.amstudyai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

private val Navy = Color(0xFF08152F)
private val Blue = Color(0xFF2864F0)
private val Panel = Color(0xFF12264A)
private val Cyan = Color(0xFF65C9FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AMstudyApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun AMstudyApp() {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var apiBase by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("سلام! من AMstudy AI هستم 📚\\nسؤالت را درباره درس‌ها بپرس تا با هم یاد بگیریم.", false)
        )
    }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Navy).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).background(Color.White, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("AM", color = Navy, fontWeight = FontWeight.Black, fontSize = 20.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("AMstudy AI", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("دستیار هوشمند آموزشی", fontSize = 12.sp, color = Cyan)
                }
                Icon(Icons.Default.MenuBook, contentDescription = null, tint = Cyan, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("چی می‌خوای یاد بگیری؟", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ریاضی", "علوم", "زبان").forEach { subject ->
                    AssistChip(
                        onClick = { input = "لطفاً یک مبحث مهم $subject را ساده و مرحله‌به‌مرحله توضیح بده." },
                        label = { Text(subject) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = Panel, labelColor = Color.White
                        )
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.fromUser) Arrangement.Start else Arrangement.End
                    ) {
                        Surface(
                            color = if (msg.fromUser) Blue else Panel,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth(0.88f)
                        ) {
                            Text(msg.text, color = Color.White, modifier = Modifier.padding(13.dp), lineHeight = 22.sp)
                        }
                    }
                }
                if (busy) item { Text("در حال فکر کردن…", color = Cyan) }
            }
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(10.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                    decorationBox = { inner ->
                        if (input.isEmpty()) Text("سؤالت را اینجا بنویس…", color = Color.LightGray)
                        inner()
                    }
                )
                IconButton(
                    enabled = input.isNotBlank() && !busy,
                    onClick = {
                        val question = input.trim()
                        input = ""
                        messages.add(ChatMessage(question, true))
                        busy = true
                        scope.launch {
                            val answer = askStudyBackend(apiBase, question)
                            messages.add(ChatMessage(answer, false))
                            busy = false
                        }
                    }
                ) {
                    Icon(Icons.Default.Send, contentDescription = "ارسال", tint = Cyan)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "اتصال هوش مصنوعی: برای فعال‌شدن پاسخ آنلاین، نشانی سرور امن باید تنظیم شود.",
                color = Color(0xFF9DB1D2), fontSize = 10.sp
            )
        }
    }
}

private suspend fun askStudyBackend(baseUrl: String, question: String): String =
    withContext(Dispatchers.IO) {
        if (baseUrl.isBlank()) {
            return@withContext "ظاهر و محیط برنامه آماده است؛ اما اتصال آنلاین هنوز پیکربندی نشده. برای فعال‌کردن هوش مصنوعی باید یک سرور امن به برنامه متصل شود. کلید محرمانه سرویس هوش مصنوعی نباید داخل فایل APK قرار بگیرد."
        }
        try {
            val url = URL(baseUrl.trimEnd('/') + "/chat")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val body = JSONObject().put("message", question).put("app", "AMstudy AI").toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            conn.disconnect()
            JSONObject(response).optString("reply", "پاسخ معتبری از سرور دریافت نشد.")
        } catch (e: Exception) {
            "ارتباط با سرور برقرار نشد. اتصال اینترنت و نشانی سرور را بررسی کن."
        }
    }
